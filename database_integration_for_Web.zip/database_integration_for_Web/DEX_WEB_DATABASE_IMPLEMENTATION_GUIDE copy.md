# DEX WEB APPLICATION - DATABASE IMPLEMENTATION GUIDE

## 🎯 **IMPLEMENTATION OVERVIEW**

This guide provides step-by-step instructions for implementing the DEX database integration in your web application, ensuring complete compatibility with the mobile app's data structure and functionality.

---

## 📋 **1. MIGRATION PROCESS SETUP**

### **Step 1: Migration File Prioritization**

#### **CRITICAL MIGRATIONS (Must Apply First):**
```bash
# Core Infrastructure (Apply in this exact order)
1. 20240522000000_update_users_table.sql          # User table foundation
2. 20240523000000_create_notification_settings.sql # Notification system
3. 20240524000000_add_avatar_url.sql              # User avatars
4. 20250127000001_fix_users_table_constraints.sql # User constraints
5. 20250127000002_add_unique_constraints.sql      # Data integrity
6. 20250128000000_fix_auth_policies.sql           # Authentication system
7. 20250128000001_fix_database_registration_issues.sql # Registration fixes
8. 20250128000002_update_phone_format_constraint.sql   # Phone validation
9. 20250128000003_fix_rls_policy_issues.sql       # Security policies
```

#### **WALLET SYSTEM MIGRATIONS (Apply Second):**
```bash
# Wallet Infrastructure
10. 20250523_generated_wallets.sql                # App-generated wallets
11. 20250523_wallet_connections.sql               # External wallet connections
12. 20250523_wallet_preferences.sql               # User wallet preferences
13. 20250523_wallet_settings.sql                  # Individual wallet settings
14. 20250601000000_fix_wallet_settings_table.sql  # Wallet settings fixes
15. 20250101_enhanced_wallet_schema.sql           # Enhanced wallet features
16. 20250128_add_slippage_tolerance.sql           # Trading settings
```

#### **ADMIN & COMPLIANCE MIGRATIONS (Apply Third):**
```bash
# Admin and Compliance Systems
17. 20250126000000_create_admin_system.sql        # Admin management
18. 20250127000000_create_kyc_table.sql           # KYC verification
19. 20250127000001_create_aml_table.sql           # AML compliance
20. 20240601000000_update_kyc_table.sql           # KYC enhancements
```

#### **ADVANCED FEATURES (Apply Fourth - Optional):**
```bash
# Advanced Trading and DeFi Features
21. 20250523_transaction_categories.sql           # Transaction categorization
22. 20250523_defi_staking.sql                     # DeFi staking
23. 20250101_phase4_defi_integration.sql          # DeFi integration
24. 20250101_phase4_advanced_trading.sql          # Advanced trading
25. 20250101_phase4_3_cross_chain_bridge.sql      # Cross-chain bridge
26. 20250101_phase4_5_social_trading.sql          # Social trading
27. 20250125000000_create_chat_system.sql         # Chat system
28. 20250127000003_cleanup_duplicate_data.sql     # Data cleanup
```

### **Step 2: Migration Application Script**

Create this script to apply migrations systematically:

```bash
#!/bin/bash
# apply_dex_migrations.sh

set -e  # Exit on any error

SUPABASE_PROJECT_ID="your-project-id"
SUPABASE_DB_PASSWORD="your-db-password"

echo "🚀 Starting DEX Database Migration Process..."

# Critical migrations array
CRITICAL_MIGRATIONS=(
    "20240522000000_update_users_table.sql"
    "20240523000000_create_notification_settings.sql"
    "20240524000000_add_avatar_url.sql"
    "20250127000001_fix_users_table_constraints.sql"
    "20250127000002_add_unique_constraints.sql"
    "20250128000000_fix_auth_policies.sql"
    "20250128000001_fix_database_registration_issues.sql"
    "20250128000002_update_phone_format_constraint.sql"
    "20250128000003_fix_rls_policy_issues.sql"
)

# Wallet system migrations
WALLET_MIGRATIONS=(
    "20250523_generated_wallets.sql"
    "20250523_wallet_connections.sql"
    "20250523_wallet_preferences.sql"
    "20250523_wallet_settings.sql"
    "20250601000000_fix_wallet_settings_table.sql"
    "20250101_enhanced_wallet_schema.sql"
    "20250128_add_slippage_tolerance.sql"
)

# Admin and compliance migrations
ADMIN_MIGRATIONS=(
    "20250126000000_create_admin_system.sql"
    "20250127000000_create_kyc_table.sql"
    "20250127000001_create_aml_table.sql"
    "20240601000000_update_kyc_table.sql"
)

# Function to apply migration with error handling
apply_migration() {
    local migration_file=$1
    local category=$2
    
    echo "📄 Applying $category migration: $migration_file"
    
    if [ -f "migrations/$migration_file" ]; then
        # Apply migration using Supabase CLI
        if supabase db push --file "migrations/$migration_file"; then
            echo "✅ Successfully applied: $migration_file"
            
            # Verify migration was applied
            verify_migration "$migration_file"
        else
            echo "❌ Failed to apply: $migration_file"
            echo "🔍 Check the error above and resolve before continuing"
            exit 1
        fi
    else
        echo "⚠️  Migration file not found: $migration_file"
    fi
    
    echo "⏳ Waiting 2 seconds before next migration..."
    sleep 2
}

# Function to verify migration
verify_migration() {
    local migration_file=$1
    echo "🔍 Verifying migration: $migration_file"
    
    # Check if migration is recorded in supabase_migrations table
    local migration_name=$(basename "$migration_file" .sql)
    
    # This would need to be adapted based on your verification method
    echo "✅ Migration verification completed for: $migration_file"
}

# Apply migrations in order
echo "🔧 Phase 1: Applying Critical Migrations..."
for migration in "${CRITICAL_MIGRATIONS[@]}"; do
    apply_migration "$migration" "CRITICAL"
done

echo "💰 Phase 2: Applying Wallet System Migrations..."
for migration in "${WALLET_MIGRATIONS[@]}"; do
    apply_migration "$migration" "WALLET"
done

echo "👑 Phase 3: Applying Admin & Compliance Migrations..."
for migration in "${ADMIN_MIGRATIONS[@]}"; do
    apply_migration "$migration" "ADMIN"
done

echo "🎉 All critical migrations applied successfully!"
echo "📋 Run verification script to ensure everything is working correctly"
```

### **Step 3: Migration Error Handling**

#### **Common Migration Errors and Solutions:**

```sql
-- Error: Constraint already exists
-- Solution: Add IF NOT EXISTS checks
ALTER TABLE users ADD CONSTRAINT IF NOT EXISTS users_email_unique UNIQUE (email);

-- Error: Column already exists
-- Solution: Add IF NOT EXISTS checks
ALTER TABLE users ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'active';

-- Error: Function already exists
-- Solution: Use CREATE OR REPLACE
CREATE OR REPLACE FUNCTION handle_new_user() RETURNS trigger AS $$
-- function body
$$ LANGUAGE plpgsql;

-- Error: Policy already exists
-- Solution: Drop and recreate
DROP POLICY IF EXISTS "Users can view their own data" ON users;
CREATE POLICY "Users can view their own data" ON users FOR SELECT USING (auth.uid() = auth_id);
```

### **Step 4: Migration Verification Script**

```sql
-- verify_migrations.sql
-- Run this after each migration phase to verify success

-- Check critical tables exist
SELECT 
    table_name,
    CASE 
        WHEN table_name IN ('users', 'notification_settings') THEN 'CRITICAL'
        WHEN table_name LIKE '%wallet%' THEN 'WALLET'
        WHEN table_name LIKE '%admin%' THEN 'ADMIN'
        ELSE 'OTHER'
    END as category
FROM information_schema.tables 
WHERE table_schema = 'public' 
ORDER BY category, table_name;

-- Check RLS is enabled on critical tables
SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_enabled
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename IN ('users', 'wallets', 'generated_wallets', 'admin_users')
ORDER BY tablename;

-- Check critical constraints exist
SELECT 
    tc.table_name,
    tc.constraint_name,
    tc.constraint_type
FROM information_schema.table_constraints tc
WHERE tc.table_schema = 'public'
AND tc.table_name IN ('users', 'wallets', 'generated_wallets')
ORDER BY tc.table_name, tc.constraint_type;

-- Check critical functions exist
SELECT 
    routine_name,
    routine_type,
    security_type
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name IN ('handle_new_user', 'check_admin_permission', 'log_admin_activity')
ORDER BY routine_name;

-- Verify trigger exists
SELECT 
    trigger_name,
    event_manipulation,
    action_timing,
    event_object_table
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND trigger_name = 'on_auth_user_created';
```

---

## 🔐 **2. AUTHENTICATION SYSTEM CONFIGURATION**

### **Step 1: Supabase Client Setup for Web**

Create your Supabase client configuration:

```typescript
// src/lib/supabase.ts
import { createClient } from '@supabase/supabase-js'
import type { Database } from './database.types'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce', // Same as mobile app
    storageKey: 'dex-web-auth-token'
  },
  global: {
    headers: {
      'X-Client-Info': 'dex-web-app'
    }
  },
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// Auth state change handler
supabase.auth.onAuthStateChange((event, session) => {
  console.log('Auth state change:', event, session?.user?.email)
  
  if (event === 'SIGNED_IN' && session?.user?.email_confirmed_at) {
    console.log('✅ Email confirmed, user signed in')
  }
  
  if (event === 'SIGNED_OUT') {
    console.log('👋 User signed out')
  }
})
```

### **Step 2: Authentication Hook Implementation**

```typescript
// src/hooks/useAuth.ts
import { useEffect, useState } from 'react'
import { User, Session } from '@supabase/supabase-js'
import { supabase } from '@/lib/supabase'

interface AuthState {
  user: User | null
  session: Session | null
  loading: boolean
}

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    session: null,
    loading: true
  })

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setAuthState({
        user: session?.user ?? null,
        session,
        loading: false
      })
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setAuthState({
          user: session?.user ?? null,
          session,
          loading: false
        })

        // Handle email confirmation
        if (event === 'SIGNED_IN' && session?.user?.email_confirmed_at) {
          // User profile should be automatically created by trigger
          console.log('✅ User signed in with confirmed email')
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const signUp = async (email: string, password: string, metadata: {
    full_name: string
    phone: string
  }) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: metadata,
        emailRedirectTo: `${window.location.origin}/auth/confirm`
      }
    })

    if (error) throw error
    return { needsVerification: !data.user?.email_confirmed_at, email }
  }

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password
    })
    if (error) throw error
  }

  const signOut = async () => {
    const { error } = await supabase.auth.signOut()
    if (error) throw error
  }

  const resendVerification = async (email: string) => {
    const { error } = await supabase.auth.resend({
      type: 'signup',
      email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/confirm`
      }
    })
    if (error) throw error
  }

  return {
    ...authState,
    signUp,
    signIn,
    signOut,
    resendVerification
  }
}
```

### **Step 3: User Profile Creation Trigger**

Ensure this trigger function is applied (from migration files):

```sql
-- This should be in your migrations already, but verify it exists
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
SECURITY DEFINER
SET search_path = public, auth
LANGUAGE plpgsql AS $$
BEGIN
  -- Insert user profile automatically when auth user is created
  INSERT INTO public.users (auth_id, email, full_name, phone, status)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', 'User'),
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    'active'
  );
  
  RAISE LOG 'Successfully created user profile for auth_id: %', NEW.id;
  RETURN NEW;
EXCEPTION
  WHEN unique_violation THEN
    -- User profile already exists, continue
    RETURN NEW;
  WHEN OTHERS THEN
    -- Log error but don't fail the auth process
    RAISE WARNING 'Failed to create user profile: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();
```

### **Step 4: RLS Policies Verification**

Verify these critical RLS policies are in place:

```sql
-- Users table policies
CREATE POLICY "Users can view their own profile"
  ON public.users FOR SELECT
  USING (auth.uid() = auth_id);

CREATE POLICY "Users can update their own profile"
  ON public.users FOR UPDATE
  USING (auth.uid() = auth_id)
  WITH CHECK (auth.uid() = auth_id);

-- Wallets table policies
CREATE POLICY "Users can view their own wallets"
  ON public.wallets FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own wallets"
  ON public.wallets FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own wallets"
  ON public.wallets FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Generated wallets policies
CREATE POLICY "Users can view their own generated wallets"
  ON public.generated_wallets FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own generated wallets"
  ON public.generated_wallets FOR INSERT
  WITH CHECK (auth.uid() = user_id);
```

---

## 🔗 **3. DATABASE CONNECTION STRATEGY**

### **Option A: Same Supabase Project (Recommended)**

#### **Advantages:**
- ✅ Perfect data consistency between mobile and web
- ✅ Shared user accounts and authentication
- ✅ Real-time synchronization
- ✅ Single source of truth for all data
- ✅ Simplified maintenance and updates

#### **Implementation Steps:**

```typescript
// Use the exact same project configuration
const SUPABASE_CONFIG = {
  url: "https://besdtjhbciefgnokaasa.supabase.co",
  anonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJlc2R0amhiY2llZmdub2thYXNhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUxNTY5NjMsImV4cCI6MjA2MDczMjk2M30.DutwrIF7cqFqG5JBBDNYOxDP-WT72-5ca5PonBzpHAI"
}

// Add client identification for analytics
export const supabase = createClient<Database>(
  SUPABASE_CONFIG.url,
  SUPABASE_CONFIG.anonKey,
  {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
      detectSessionInUrl: true,
      flowType: 'pkce',
      storageKey: 'dex-web-auth-token' // Different from mobile
    },
    global: {
      headers: {
        'X-Client-Info': 'dex-web-app',
        'X-Client-Version': '1.0.0'
      }
    }
  }
)
```

#### **Data Consistency Measures:**

```typescript
// src/lib/dataConsistency.ts
export class DataConsistencyManager {
  private static instance: DataConsistencyManager

  static getInstance() {
    if (!this.instance) {
      this.instance = new DataConsistencyManager()
    }
    return this.instance
  }

  // Subscribe to real-time changes from mobile app
  subscribeToWalletChanges(userId: string, callback: (payload: any) => void) {
    return supabase
      .channel('wallet_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'wallets',
          filter: `user_id=eq.${userId}`
        },
        callback
      )
      .subscribe()
  }

  // Subscribe to transaction changes
  subscribeToTransactionChanges(userId: string, callback: (payload: any) => void) {
    return supabase
      .channel('transaction_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'transactions',
          filter: `user_id=eq.${userId}`
        },
        callback
      )
      .subscribe()
  }

  // Conflict resolution for concurrent updates
  async resolveWalletConflict(walletId: string, webData: any, mobileData: any) {
    // Implement last-write-wins or custom conflict resolution
    const latestUpdate = webData.updated_at > mobileData.updated_at ? webData : mobileData

    const { error } = await supabase
      .from('wallets')
      .update({
        ...latestUpdate,
        updated_at: new Date().toISOString(),
        conflict_resolved: true
      })
      .eq('id', walletId)

    if (error) throw error
    return latestUpdate
  }
}
```

### **Option B: Separate Supabase Project**

#### **When to Choose This Option:**
- Different user bases for mobile vs web
- Separate billing/analytics requirements
- Different compliance requirements
- Staged rollout strategy

#### **Implementation Steps:**

```bash
# Create new Supabase project
supabase projects create dex-web-app

# Copy all migration files to new project
cp -r mobile-app/supabase/migrations/ web-app/supabase/migrations/

# Apply migrations to new project
supabase db push --project-ref your-new-project-id
```

#### **Data Synchronization Service:**

```typescript
// src/lib/dataSynchronization.ts
export class DataSynchronizationService {
  private mobileSupabase: SupabaseClient
  private webSupabase: SupabaseClient

  constructor() {
    this.mobileSupabase = createClient(MOBILE_SUPABASE_URL, MOBILE_SUPABASE_KEY)
    this.webSupabase = createClient(WEB_SUPABASE_URL, WEB_SUPABASE_KEY)
  }

  // Sync user data from mobile to web
  async syncUserFromMobile(mobileUserId: string, webUserId: string) {
    // Get user data from mobile app
    const { data: mobileUser, error: mobileError } = await this.mobileSupabase
      .from('users')
      .select('*')
      .eq('id', mobileUserId)
      .single()

    if (mobileError) throw mobileError

    // Update web app user
    const { error: webError } = await this.webSupabase
      .from('users')
      .update({
        full_name: mobileUser.full_name,
        phone: mobileUser.phone,
        avatar_url: mobileUser.avatar_url,
        // Don't sync sensitive data like auth_id
        synced_from_mobile: true,
        last_sync: new Date().toISOString()
      })
      .eq('id', webUserId)

    if (webError) throw webError
  }

  // Sync wallet data (read-only from mobile)
  async syncWalletsFromMobile(mobileUserId: string, webUserId: string) {
    const { data: mobileWallets, error } = await this.mobileSupabase
      .from('wallets')
      .select('*')
      .eq('user_id', mobileUserId)

    if (error) throw error

    // Insert as read-only wallets in web app
    const webWallets = mobileWallets.map(wallet => ({
      ...wallet,
      user_id: webUserId,
      is_synced_from_mobile: true,
      is_read_only: true, // Web app can't modify mobile wallets
      original_mobile_id: wallet.id
    }))

    const { error: insertError } = await this.webSupabase
      .from('synced_mobile_wallets')
      .upsert(webWallets)

    if (insertError) throw insertError
  }
}
```

---

## 🌐 **4. ENVIRONMENT CONFIGURATION**

### **Environment Variables Setup**

Create these environment files:

```bash
# .env.local (for development)
NEXT_PUBLIC_SUPABASE_URL=https://besdtjhbciefgnokaasa.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJlc2R0amhiY2llZmdub2thYXNhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUxNTY5NjMsImV4cCI6MjA2MDczMjk2M30.DutwrIF7cqFqG5JBBDNYOxDP-WT72-5ca5PonBzpHAI

# Optional: Service role key for admin operations (keep secure!)
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# App configuration
NEXT_PUBLIC_APP_NAME=DEX Web Platform
NEXT_PUBLIC_APP_VERSION=1.0.0
NEXT_PUBLIC_ENVIRONMENT=development

# External API keys (if needed)
NEXT_PUBLIC_COINGECKO_API_KEY=your-coingecko-key
NEXT_PUBLIC_ETHERSCAN_API_KEY=your-etherscan-key
```

```bash
# .env.production (for production deployment)
NEXT_PUBLIC_SUPABASE_URL=https://besdtjhbciefgnokaasa.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJlc2R0amhiY2llZmdub2thYXNhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUxNTY5NjMsImV4cCI6MjA2MDczMjk2M30.DutwrIF7cqFqG5JBBDNYOxDP-WT72-5ca5PonBzpHAI
SUPABASE_SERVICE_ROLE_KEY=your-production-service-role-key
NEXT_PUBLIC_ENVIRONMENT=production
```

### **Web-Specific Supabase Configuration**

```typescript
// src/lib/supabaseConfig.ts
import { createClient } from '@supabase/supabase-js'
import type { Database } from './database.types'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Detect environment
const isProduction = process.env.NEXT_PUBLIC_ENVIRONMENT === 'production'
const isDevelopment = process.env.NODE_ENV === 'development'

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce',
    storageKey: 'dex-web-auth-token',
    // Web-specific auth settings
    debug: isDevelopment,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined
  },
  global: {
    headers: {
      'X-Client-Info': 'dex-web-app',
      'X-Client-Version': process.env.NEXT_PUBLIC_APP_VERSION || '1.0.0',
      'X-Client-Platform': 'web'
    }
  },
  realtime: {
    params: {
      eventsPerSecond: isProduction ? 10 : 5 // Throttle in development
    }
  },
  db: {
    schema: 'public'
  }
})

// Service role client for admin operations (server-side only)
export const supabaseAdmin = createClient<Database>(
  supabaseUrl,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false
    }
  }
)
```

### **CORS and Security Configuration**

```typescript
// next.config.js
/** @type {import('next').NextConfig} */
const nextConfig = {
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: '*' },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type, Authorization' },
        ],
      },
    ]
  },

  // Environment variables validation
  env: {
    CUSTOM_KEY: process.env.CUSTOM_KEY,
  },

  // Security headers
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          {
            key: 'X-Frame-Options',
            value: 'DENY',
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff',
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin',
          },
        ],
      },
    ]
  },
}

module.exports = nextConfig
```

---

## ✅ **5. TESTING AND VALIDATION**

### **Database Schema Validation Checklist**

```sql
-- schema_validation.sql
-- Run this comprehensive check after all migrations

-- 1. Verify all critical tables exist
SELECT
  'TABLES' as check_type,
  CASE
    WHEN COUNT(*) >= 15 THEN 'PASS'
    ELSE 'FAIL'
  END as status,
  COUNT(*) as table_count,
  'Expected: 15+ tables' as expected
FROM information_schema.tables
WHERE table_schema = 'public';

-- 2. Verify RLS is enabled on critical tables
SELECT
  'RLS_POLICIES' as check_type,
  CASE
    WHEN COUNT(*) >= 10 THEN 'PASS'
    ELSE 'FAIL'
  END as status,
  COUNT(*) as policy_count,
  'Expected: 10+ RLS policies' as expected
FROM pg_policies
WHERE schemaname = 'public';

-- 3. Verify critical constraints exist
SELECT
  'CONSTRAINTS' as check_type,
  CASE
    WHEN COUNT(*) >= 20 THEN 'PASS'
    ELSE 'FAIL'
  END as status,
  COUNT(*) as constraint_count,
  'Expected: 20+ constraints' as expected
FROM information_schema.table_constraints
WHERE table_schema = 'public';

-- 4. Verify critical functions exist
SELECT
  'FUNCTIONS' as check_type,
  CASE
    WHEN COUNT(*) >= 3 THEN 'PASS'
    ELSE 'FAIL'
  END as status,
  COUNT(*) as function_count,
  'Expected: 3+ functions' as expected
FROM information_schema.routines
WHERE routine_schema = 'public'
AND routine_name IN ('handle_new_user', 'check_admin_permission', 'log_admin_activity');

-- 5. Verify triggers exist
SELECT
  'TRIGGERS' as check_type,
  CASE
    WHEN COUNT(*) >= 1 THEN 'PASS'
    ELSE 'FAIL'
  END as status,
  COUNT(*) as trigger_count,
  'Expected: 1+ triggers' as expected
FROM information_schema.triggers
WHERE trigger_schema = 'public'
AND trigger_name = 'on_auth_user_created';
```

### **RLS Policy Testing Script**

```typescript
// src/tests/rlsPolicyTests.ts
import { supabase } from '@/lib/supabase'

export class RLSPolicyTester {

  async testUserDataAccess() {
    console.log('🔒 Testing RLS policies for user data access...')

    // Test 1: User can only see their own data
    try {
      const { data: userData, error } = await supabase
        .from('users')
        .select('*')

      if (error) {
        console.log('❌ RLS Test Failed: User data access error:', error.message)
        return false
      }

      // Should only return current user's data
      if (userData.length <= 1) {
        console.log('✅ RLS Test Passed: User can only access own data')
        return true
      } else {
        console.log('❌ RLS Test Failed: User can access other users data')
        return false
      }
    } catch (error) {
      console.log('❌ RLS Test Error:', error)
      return false
    }
  }

  async testWalletDataAccess() {
    console.log('🔒 Testing RLS policies for wallet data access...')

    try {
      const { data: walletData, error } = await supabase
        .from('wallets')
        .select('*')

      if (error && error.code === 'PGRST301') {
        console.log('✅ RLS Test Passed: Wallet access properly restricted')
        return true
      }

      if (!error && walletData) {
        // Check if all wallets belong to current user
        const { data: { user } } = await supabase.auth.getUser()
        const allBelongToUser = walletData.every(wallet => wallet.user_id === user?.id)

        if (allBelongToUser) {
          console.log('✅ RLS Test Passed: User can only access own wallets')
          return true
        } else {
          console.log('❌ RLS Test Failed: User can access other users wallets')
          return false
        }
      }

      return false
    } catch (error) {
      console.log('❌ RLS Test Error:', error)
      return false
    }
  }

  async testAdminDataAccess() {
    console.log('🔒 Testing RLS policies for admin data access...')

    try {
      const { data: adminData, error } = await supabase
        .from('admin_users')
        .select('*')

      // Non-admin users should not be able to access admin data
      if (error && error.code === 'PGRST301') {
        console.log('✅ RLS Test Passed: Admin data properly restricted')
        return true
      }

      console.log('❌ RLS Test Failed: Non-admin can access admin data')
      return false
    } catch (error) {
      console.log('❌ RLS Test Error:', error)
      return false
    }
  }

  async runAllTests() {
    console.log('🚀 Starting comprehensive RLS policy tests...')

    const results = {
      userDataAccess: await this.testUserDataAccess(),
      walletDataAccess: await this.testWalletDataAccess(),
      adminDataAccess: await this.testAdminDataAccess()
    }

    const passedTests = Object.values(results).filter(Boolean).length
    const totalTests = Object.keys(results).length

    console.log(`📊 RLS Test Results: ${passedTests}/${totalTests} tests passed`)

    if (passedTests === totalTests) {
      console.log('🎉 All RLS policy tests passed!')
    } else {
      console.log('⚠️ Some RLS policy tests failed. Review security configuration.')
    }

    return results
  }
}
```

### **Data Consistency Testing**

```typescript
// src/tests/dataConsistencyTests.ts
import { supabase } from '@/lib/supabase'

export class DataConsistencyTester {

  async testUserProfileCreation() {
    console.log('👤 Testing automatic user profile creation...')

    // This test should be run with a test user account
    try {
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        console.log('❌ No authenticated user for testing')
        return false
      }

      // Check if user profile exists in public.users table
      const { data: userProfile, error } = await supabase
        .from('users')
        .select('*')
        .eq('auth_id', user.id)
        .single()

      if (error) {
        console.log('❌ User profile creation test failed:', error.message)
        return false
      }

      if (userProfile) {
        console.log('✅ User profile creation test passed')
        console.log('📋 Profile data:', {
          id: userProfile.id,
          email: userProfile.email,
          full_name: userProfile.full_name,
          status: userProfile.status
        })
        return true
      }

      return false
    } catch (error) {
      console.log('❌ User profile creation test error:', error)
      return false
    }
  }

  async testWalletDataIntegrity() {
    console.log('💰 Testing wallet data integrity...')

    try {
      // Check for orphaned wallet records
      const { data: orphanedWallets, error: orphanError } = await supabase
        .from('wallets')
        .select(`
          id,
          user_id,
          users!inner(id)
        `)

      if (orphanError) {
        console.log('❌ Wallet integrity test failed:', orphanError.message)
        return false
      }

      // Check for duplicate wallet addresses
      const { data: duplicateAddresses, error: dupError } = await supabase
        .rpc('check_duplicate_wallet_addresses')

      if (dupError) {
        console.log('⚠️ Could not check for duplicate addresses:', dupError.message)
      }

      console.log('✅ Wallet data integrity test passed')
      return true
    } catch (error) {
      console.log('❌ Wallet integrity test error:', error)
      return false
    }
  }

  async testTransactionDataConsistency() {
    console.log('💸 Testing transaction data consistency...')

    try {
      // Check for transactions with invalid wallet references
      const { data: invalidTransactions, error } = await supabase
        .from('transactions')
        .select(`
          id,
          wallet_id,
          wallets!inner(id)
        `)

      if (error) {
        console.log('❌ Transaction consistency test failed:', error.message)
        return false
      }

      console.log('✅ Transaction data consistency test passed')
      return true
    } catch (error) {
      console.log('❌ Transaction consistency test error:', error)
      return false
    }
  }

  async runAllTests() {
    console.log('🚀 Starting data consistency tests...')

    const results = {
      userProfileCreation: await this.testUserProfileCreation(),
      walletDataIntegrity: await this.testWalletDataIntegrity(),
      transactionDataConsistency: await this.testTransactionDataConsistency()
    }

    const passedTests = Object.values(results).filter(Boolean).length
    const totalTests = Object.keys(results).length

    console.log(`📊 Data Consistency Results: ${passedTests}/${totalTests} tests passed`)

    return results
  }
}
```

### **Mobile-Web Data Sync Testing**

```typescript
// src/tests/mobileSyncTests.ts
import { supabase } from '@/lib/supabase'

export class MobileSyncTester {

  async testRealTimeSync() {
    console.log('📱 Testing real-time sync between mobile and web...')

    return new Promise((resolve) => {
      let syncReceived = false

      // Subscribe to wallet changes
      const subscription = supabase
        .channel('sync_test')
        .on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'wallets'
          },
          (payload) => {
            console.log('📡 Real-time sync received:', payload)
            syncReceived = true
            subscription.unsubscribe()
            resolve(true)
          }
        )
        .subscribe()

      // Timeout after 10 seconds
      setTimeout(() => {
        if (!syncReceived) {
          console.log('⚠️ Real-time sync test timed out')
          subscription.unsubscribe()
          resolve(false)
        }
      }, 10000)

      // Trigger a change to test sync
      this.triggerTestChange()
    })
  }

  private async triggerTestChange() {
    // Create a test wallet to trigger sync
    const { data: { user } } = await supabase.auth.getUser()

    if (user) {
      await supabase
        .from('wallets')
        .insert({
          user_id: user.id,
          wallet_name: 'Sync Test Wallet',
          wallet_type: 'generated',
          wallet_address: '0x' + Math.random().toString(16).substr(2, 40),
          network: 'ethereum',
          provider: 'test',
          source_table: 'test',
          source_id: crypto.randomUUID()
        })
    }
  }

  async testDataConsistencyBetweenPlatforms() {
    console.log('🔄 Testing data consistency between platforms...')

    try {
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        console.log('❌ No authenticated user for testing')
        return false
      }

      // Get user data
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('*')
        .eq('auth_id', user.id)
        .single()

      if (userError) {
        console.log('❌ Could not fetch user data:', userError.message)
        return false
      }

      // Get wallet data
      const { data: walletData, error: walletError } = await supabase
        .from('wallets')
        .select('*')
        .eq('user_id', user.id)

      if (walletError) {
        console.log('❌ Could not fetch wallet data:', walletError.message)
        return false
      }

      console.log('✅ Data consistency test passed')
      console.log('📊 User has', walletData.length, 'wallets')

      return true
    } catch (error) {
      console.log('❌ Data consistency test error:', error)
      return false
    }
  }
}
```

### **Comprehensive Test Runner**

```typescript
// src/tests/runAllTests.ts
import { RLSPolicyTester } from './rlsPolicyTests'
import { DataConsistencyTester } from './dataConsistencyTests'
import { MobileSyncTester } from './mobileSyncTests'

export async function runComprehensiveTests() {
  console.log('🚀 Starting comprehensive DEX database tests...')
  console.log('=' .repeat(50))

  const rlsTester = new RLSPolicyTester()
  const consistencyTester = new DataConsistencyTester()
  const syncTester = new MobileSyncTester()

  // Run all test suites
  const results = {
    rlsPolicies: await rlsTester.runAllTests(),
    dataConsistency: await consistencyTester.runAllTests(),
    mobileSync: {
      realTimeSync: await syncTester.testRealTimeSync(),
      dataConsistency: await syncTester.testDataConsistencyBetweenPlatforms()
    }
  }

  // Calculate overall results
  const allTests = [
    ...Object.values(results.rlsPolicies),
    ...Object.values(results.dataConsistency),
    ...Object.values(results.mobileSync)
  ]

  const passedTests = allTests.filter(Boolean).length
  const totalTests = allTests.length

  console.log('=' .repeat(50))
  console.log(`📊 FINAL RESULTS: ${passedTests}/${totalTests} tests passed`)

  if (passedTests === totalTests) {
    console.log('🎉 ALL TESTS PASSED! Database integration is ready for production.')
  } else {
    console.log('⚠️ Some tests failed. Please review and fix issues before deployment.')
  }

  return {
    success: passedTests === totalTests,
    results,
    summary: {
      passed: passedTests,
      total: totalTests,
      percentage: Math.round((passedTests / totalTests) * 100)
    }
  }
}

// Usage in your app
// import { runComprehensiveTests } from '@/tests/runAllTests'
// runComprehensiveTests()
```

---

## 📅 **IMPLEMENTATION TIMELINE**

### **Week 1: Foundation Setup**
- [ ] Set up Supabase project (same or new)
- [ ] Apply critical migrations (1-9)
- [ ] Configure authentication system
- [ ] Test user registration and login

### **Week 2: Core Features**
- [ ] Apply wallet system migrations (10-16)
- [ ] Implement wallet management
- [ ] Test wallet creation and connection
- [ ] Set up real-time subscriptions

### **Week 3: Admin & Security**
- [ ] Apply admin system migrations (17-20)
- [ ] Configure RLS policies
- [ ] Test security restrictions
- [ ] Implement admin functionality

### **Week 4: Advanced Features & Testing**
- [ ] Apply optional migrations (21-28)
- [ ] Run comprehensive test suite
- [ ] Performance optimization
- [ ] Production deployment preparation

### **Week 5: Production Deployment**
- [ ] Final security audit
- [ ] Performance testing
- [ ] Production deployment
- [ ] Monitor data consistency

This implementation guide provides everything needed to successfully integrate the DEX database into your web application with complete compatibility and data consistency with the mobile app.
```

### **Deployment Configuration**

```yaml
# vercel.json (for Vercel deployment)
{
  "build": {
    "env": {
      "NEXT_PUBLIC_SUPABASE_URL": "@supabase-url",
      "NEXT_PUBLIC_SUPABASE_ANON_KEY": "@supabase-anon-key",
      "SUPABASE_SERVICE_ROLE_KEY": "@supabase-service-role-key"
    }
  },
  "functions": {
    "app/api/**/*.ts": {
      "maxDuration": 30
    }
  }
}
```
```
